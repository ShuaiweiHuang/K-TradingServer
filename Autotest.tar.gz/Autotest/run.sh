#NETWORK SETTING
IP=127.0.0.1
PORT=8998

#ACCOUNT SETTING
PASSWORD=testtest
USERID=P123456789
USERACC=1234567

#RUNNING PARAMETERS
LOOPNUM=100
BEGIN=0
END=5
SILENT=0

NOW=$(date +"%Y%m%d_%H%M%S")

rm -rf ./Report/*.txt;
mkdir -p ./Report

if [ "$SILENT" == "1" ]
then
	for ((THREADEXP=$BEGIN; THREADEXP <= $END; THREADEXP++))
	do
		#				ID		PASSWORD	ISLOGIN		LOOPNUM		ORDERNUM	THREADEXP	ACCOUNT		TESTPATH	IP		PORT		EXEC_RESULT
		./sslconnect $USERID	$PASSWORD		0		$LOOPNUM		0		$THREADEXP	$USERACC		S		$IP		$PORT		&> ./Report/Report_item1_exp$THREADEXP.txt; Result[1]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		0		$THREADEXP	$USERACC		S		$IP     $PORT		&> ./Report/Report_item2_exp$THREADEXP.txt; Result[2]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		1		$THREADEXP	$USERACC 		S		$IP     $PORT		&> ./Report/Report_item3_exp$THREADEXP.txt; Result[3]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		1		$THREADEXP	$USERACC		T		$IP     $PORT		&> ./Report/Report_item4_exp$THREADEXP.txt; Result[4]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		100		$THREADEXP	$USERACC		S		$IP     $PORT		&> ./Report/Report_item5_exp$THREADEXP.txt; Result[5]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		100		$THREADEXP	$USERACC		T		$IP     $PORT		&> ./Report/Report_item6_exp$THREADEXP.txt; Result[6]=$?;
		#./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		1		$THREADEXP	$USERACC		U		$IP     $PORT		&> ./Report/Report_item7_exp$THREADEXP.txt; Result[7]=$?;
		./burstrw    $USERID	$PASSWORD		1		1				1000	0			$USERACC		T		$IP     $PORT		&> ./Report/Report_item8_exp$THREADEXP.txt; Result[7]=$?;

		for i in {1..7};
		do
			printf "Test item $i with thread exp $THREADEXP: " >> ./Report/Result_$THREADEXP.txt

			if [ "${Result[$i]}" == "0" ]; 
				then
					echo "success" >> ./Report/Result_$THREADEXP.txt;
				else
					echo "fail" >> ./Report/Result_$THREADEXP.txt;
			fi
		done
	done
	tar zcf Report_$NOW.tar.gz Report
	echo "Output Report File: Report_$NOW.tar.gz"

else

	for ((THREADEXP=$BEGIN; THREADEXP <= $END; THREADEXP++))
	do
		#				ID		PASSWORD	ISLOGIN		LOOPNUM		ORDERNUM	THREADEXP	ACCOUNT		TESTPATH	IP		PORT		EXEC_RESULT
		./sslconnect $USERID	$PASSWORD		0		$LOOPNUM		0		$THREADEXP	$USERACC		S		$IP     $PORT		;Result[1]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		0		$THREADEXP	$USERACC		S		$IP     $PORT		;Result[2]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		1		$THREADEXP	$USERACC 		S		$IP     $PORT		;Result[3]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		1		$THREADEXP	$USERACC		T		$IP     $PORT		;Result[4]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		100		$THREADEXP	$USERACC		S		$IP     $PORT		;Result[5]=$?;
		./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		100		$THREADEXP	$USERACC		T		$IP     $PORT		;Result[6]=$?;
		#./sslconnect $USERID	$PASSWORD		1		$LOOPNUM		1		$THREADEXP	$USERACC		U		$IP     $PORT		;Result[7]=$?;
		./burstrw    $USERID	$PASSWORD		1		$LOOPNUM		1000	$THREADEXP	$USERACC		T		$IP     $PORT		;Result[7]=$?;

        for i in {1..7};
        do
            printf "Test item $i with thread exp $THREADEXP: " >> ./Report/Result_$THREADEXP.txt

            if [ "${Result[$i]}" == "0" ];
                then
                    echo "success" >> ./Report/Result_$THREADEXP.txt;
                else
                    echo "fail" >> ./Report/Result_$THREADEXP.txt;
            fi
        done

	done

fi
