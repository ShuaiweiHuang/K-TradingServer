gcc -O2 -w -o sslconnect client_ssl.c -lssl -lcrypto -lpthread
gcc -O2 -w -o burstrw client_burst.c -lssl -lcrypto -lpthread
