
ps aux | grep sslconnect | awk '{print $2}' 
ps aux | grep sslconnect | awk '{print $2}' | xargs kill -9
ps aux | grep sslconnect | awk '{print $2}' | xargs kill -9
ps aux | grep sslconnect | awk '{print $2}' | xargs kill -9

ps aux | grep sslconnect | awk '{print $2}' 
