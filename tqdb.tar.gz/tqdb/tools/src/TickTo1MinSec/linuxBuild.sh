#!/bin/bash
g++ TickTo1MinSec.cpp -o ../../tick21minsec
