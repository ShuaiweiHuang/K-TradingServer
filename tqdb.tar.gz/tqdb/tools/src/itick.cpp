/*
  Copyright (c) 2015 WLDTW2008@gmail.com

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/

#include <stdio.h>
#include <cassandra.h>
#include <time.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include "common.h"
void vCheckSystex(int argc, char *argv[]) {
	if (argc >= 6)
	{
		//good
	}
	else
	{
		vMyLog(stdout, 1, "Systex Error");
		vMyLog(stdout, 1, "Systex: %s IP Port dbname dbgflag isQuote", argv[0]);
		vMyLog(stdout, 1, "        *The flag 'isQuote' means insert the quote or not.");
		vMyLog(stdout, 1, "    Ex: %s 127.0.0.1 9042 tqdb1 1 0", argv[0]);
		exit(0);
	}
}
typedef struct _ST_TICKDATA
{
	double dbDateTime;//float is microsec
	int iEPID;
	double dbPrc;
	int iVol;
	
}ST_TickData;

int iCassConnect(CassSession* session, const CassCluster* cluster)
{
    CassFuture* connect_future = cass_session_connect(session, cluster);
    int iRet = 0;
    if (cass_future_error_code(connect_future) == CASS_OK) {
        iRet = 1;
    } else {
        const char* pszMsg;
        size_t iMsgLen;
        cass_future_error_message(connect_future, &pszMsg, &iMsgLen);
        fprintf(stderr, "Unable to connect: '%.*s'\n", int(iMsgLen), pszMsg);
    }
    cass_future_free(connect_future);
    return iRet;
}
int iCassExecuteInsertStatement(CassSession* session, const char* pszInsert)
{
    CassStatement* statement = cass_statement_new(pszInsert, 0);
    CassFuture* result_future = cass_session_execute(session, statement);
    int iRet = 0;
    if(cass_future_error_code(result_future) == CASS_OK) {
        iRet = 1;
    } else {
        const char* pszMsg;
        size_t iMsgLen;
        cass_future_error_message(result_future, &pszMsg, &iMsgLen);
        fprintf(stderr, "Unable to execute statement: '%.*s'\n", int(iMsgLen), pszMsg);
    }
    cass_future_free(result_future);
    cass_statement_free(statement);
    return iRet;
}
int iGetSymbolIdx(std::vector<ST_SymbolInfo>* pvecSymbolInfo, const char* szSymbol)
{
	for (int i=0;i<int(pvecSymbolInfo->size());++i)
	{
		if (strcmp((*pvecSymbolInfo)[i].symbol.c_str(), szSymbol) == 0)
			return i;
	}
	return -1;
}
int iCheckECCIfNeed(char* szInput, int iInputLen)
{
	char* pstrECCBeg = strstr(szInput, ",ECC.1=");
	char* pstrECCEnd = NULL;
	if (pstrECCBeg == NULL)
		pstrECCEnd = strstr(szInput, ",ECC.2=");
	else
		pstrECCEnd = strstr(pstrECCBeg + 7, ",ECC.2=");

	if (pstrECCBeg == NULL && pstrECCEnd == NULL) //沒有ECC.1 也沒ECC.2 就是不驗 直接通過
		return 0;

	if (pstrECCBeg != NULL && pstrECCEnd == NULL)//有頭沒尾 不通過
		return -1;
	if (pstrECCBeg == NULL && pstrECCEnd != NULL)//沒頭有尾 不通過
		return -2;
	if (pstrECCBeg > pstrECCEnd)//頭大於尾 不通過
		return -3;
	pstrECCBeg += 7;
	pstrECCEnd += 7;
	char* pstrECCBegTail = strchr(pstrECCBeg, ',');
	char* pstrECCEndTail = strchr(pstrECCEnd, ',');
	if (pstrECCBegTail == NULL || pstrECCEndTail == NULL)//頭尾錯誤 不通過
		return -4;

	if (strstr(pstrECCBeg, ",ECC.1=") != NULL) //有兩個ECC.1 不通過
		return -20;
	if (strstr(pstrECCEnd, ",ECC.2=") != NULL) //有兩個ECC.2 不通過
		return -21;

	int iLenECCBeg = pstrECCBegTail - pstrECCBeg;
	int iLenECCEnd = pstrECCEndTail - pstrECCEnd;
	if (iLenECCBeg != iLenECCEnd)//頭尾資料長度錯誤 不通過
		return -30;
	if (iLenECCBeg == 0)//頭尾資料長度錯誤 不通過
		return -31;

	if (strncmp(pstrECCBeg, pstrECCEnd, iLenECCBeg) != 0)//頭尾資料不匹配 不通過
		return -40;

	if (strstr(szInput + 6, "00_ID=") != NULL) //有兩個00_ID
	{
		return -50;
	}
	if (strstr(szInput + 6, "01_ID=") != NULL) //有兩個01_ID
	{
		return -51;
	}
	return 1;
}







std::string& string_replace(std::string & strBig, const char* pszA, const char* pszB)
{
    int pos=0;
    int srclen=strlen(pszA);
    int dstlen=strlen(pszB);
    while( (pos=strBig.find(pszA, pos)) >= 0)
    {
        strBig.replace(pos, srclen, pszB);
        pos += dstlen;
    }
    return strBig;
}
std::string& strGetSymFilename(std::string& strSym)
{
	string_replace(strSym, "&", "\\&");
	return strSym;
}
#define LAST_TQ_LOG_DIR "/tmp/lastTQ"
int main(int argc, char *argv[]) {
	char *pszIP, *pszPort, *pszDBName;
	char szTQDBKeyVal[2048], szInsStr[4096];
        int i, iDBGFlag, isQuote;
	std::vector<ST_SymbolInfo> vecSymbolInfo;
	/* Setup and connect to cluster */
	CassCluster* cluster = cass_cluster_new();
	CassSession* session = cass_session_new();

	struct stat sb;
    	if (stat(LAST_TQ_LOG_DIR, &sb) == -1)
	{
		mkdir(LAST_TQ_LOG_DIR, S_IRWXU|(S_IRGRP|S_IXGRP)|(S_IROTH|S_IXOTH));
	}

	vCheckSystex(argc, argv);
        i = 1;
	pszIP = argv[i++];
	pszPort = argv[i++];
        pszDBName = argv[i++];
	iDBGFlag = atoi(argv[i++]);
	isQuote = atoi(argv[i++]);

	//iEPIDFilter = atoi(argv[i++]);

        cass_cluster_set_port(cluster, atoi(pszPort));
        cass_cluster_set_contact_points(cluster, pszIP);//"192.168.1.217");
        cass_cluster_set_connect_timeout(cluster, 10000);
        cass_cluster_set_request_timeout(cluster, 600000);
        cass_cluster_set_num_threads_io(cluster, 2);
	if (iCassConnect(session, cluster) == 0)
	{
		printf("Can't connect to cassandra\n");
		exit(0);
	}
	
	iQAllSymbol(&vecSymbolInfo, pszDBName, session, cluster);
	for (int k=0;k<int(vecSymbolInfo.size());++k)
	{
		if (k == 0)
			printf("All symbol count: %d\n", int(vecSymbolInfo.size()));
		printf("   Sym#%d: %s\n", k+1, vecSymbolInfo[k].symbol.c_str());
	}

	char szLine[2048];
	int iLen, iQuoteOrTick;
	char tmpC;
	int iInsertCnt = 0;
	vMyLog(stdout, 1, "Getting data from stdin.");
	fflush(stdout);
	std::map<std::string, int> mapSymHaveTick;
	std::map<std::string, int> mapSymHaveQuote;
	time_t tLastCheck = time(NULL);
	while(fgets(szLine, sizeof(szLine), stdin))
	{
		if (time(NULL)-tLastCheck>5)
		{
			tLastCheck = time(NULL);
			FILE* fp;
			char szFile[512];
			for (int j=0;j<2;++j)
			{
				std::map<std::string, int>* pmap = (j==0?&mapSymHaveTick:&mapSymHaveQuote);
                                std::map<std::string, int>::iterator it;
				for(it = pmap->begin(); it != pmap->end(); ++it)
				{
					sprintf(szFile, "%s/%s.%s", LAST_TQ_LOG_DIR, it->first.c_str(), (j==0?"LastT":"LastQ"));
					fp = fopen(szFile, "w");
					if (fp != NULL)
					{
						fprintf(fp, "%d", int(tLastCheck));
						fclose(fp);
						if (iDBGFlag)
							printf("Last tick/quote Write to %s\n", szFile);
					}
					else
					{
						printf("Error to write %s\n", szFile);
					}
				}
			}
			mapSymHaveTick.clear();
			mapSymHaveQuote.clear();
		}
		szLine[sizeof(szLine)] = '\0';
		iLen = strlen(szLine);
		while(1)
		{
			tmpC = szLine[iLen-1];
			if (tmpC == '\r' || tmpC == '\n')
			{
				iLen--;
				szLine[iLen] = '\0';
			}
			else
				break;
		}
		iQuoteOrTick = -1;
		/*
		{'ASK': 9533, 'BID': 9532, 'EPID': 3, 'V': 13403}
		{'C': 9532, 'EPID': 3, 'TC': 3194, 'V': 1}
		*/
		if (strncmp(szLine, "01_ID=", 6) == 0)
                {
			char szSymbol[32], szClose[32], szVol[32], szTC[32], szEPID[32];
			szGetValueByKey(szLine+3, "ID", szSymbol, "");
			if (1)//for Last Tick/Quote
			{
				std::string szSymFile = szSymbol;
				strGetSymFilename(szSymFile);
				mapSymHaveTick[szSymFile]=1;
			}
			//customer symbol is begin at  ^^, so if the first 2 char of the symbol is ^^, we have to skip it.
			if (strstr(szSymbol, "^^") == szSymbol)
			{
				continue;
			}
			if (iGetSymbolIdx(&vecSymbolInfo, szSymbol)<0)
			{
				ST_SymbolInfo tmpSymbolInfo;
				tmpSymbolInfo.symbol = szSymbol;
				vecSymbolInfo.push_back(tmpSymbolInfo);
			}
			szGetValueByKey(szLine+3, "C", szClose, "0");
			szGetValueByKey(szLine+3, "V", szVol, "0");
			szGetValueByKey(szLine+3, "TC", szTC, "0");
			szGetValueByKey(szLine+3, "EPID", szEPID, "0");
	

		sprintf(szTQDBKeyVal, "{'C':%s,'V':%s,'TC':%s,'EPID':%s}", szClose, szVol, szTC, szEPID);
//strcpy(szSymbol,"KK");
			sprintf(szInsStr, "insert into %s.tick (symbol, datetime, type, keyval) values ('%s', %lld, %d, %s);",
				pszDBName, szSymbol, llGetCurrentEpoch(), 1, szTQDBKeyVal);

			if (iDBGFlag==1)
				fprintf(stdout,"%s\n", szInsStr);
			
			if (iCheckECCIfNeed(szLine, strlen(szLine))>0){
				if (iCassExecuteInsertStatement(session, szInsStr) == 0)
				{
					exit(0);
				}
			}else{
				fprintf(stdout,"check error:%s\n",szLine);	
			}
			iInsertCnt++;
                        iQuoteOrTick = 1;
                }
		else if (strncmp(szLine, "00_ID=", 6) == 0)//quote
		{
			char szSymbol[32], szTmp[32];
			char *szAllowKey[] = {"BID", "ASK", "V", "EPID", NULL};
			char *pKey;
			int j, iFoundKeyCnt;
			szGetValueByKey(szLine+3, "ID", szSymbol, "");
			{//for Last Tick/Quote
				std::string szSymFile = szSymbol;
				strGetSymFilename(szSymFile);
				mapSymHaveQuote[szSymFile]=1;
			}
			if (isQuote!=1)
				continue;
			//customer symbol is begin at  ^^, so if the first 2 char of the symbol is ^^, we have to skip it.
                        if (strstr(szSymbol, "^^") == szSymbol)
                        {
                                continue;
                        }
			if (iGetSymbolIdx(&vecSymbolInfo, szSymbol)<0)
                        {
                                ST_SymbolInfo tmpSymbolInfo;
                                tmpSymbolInfo.symbol = szSymbol;
                                vecSymbolInfo.push_back(tmpSymbolInfo);
                        }
			szTQDBKeyVal[0] = '\0';
			sprintf(szTQDBKeyVal+strlen(szTQDBKeyVal), "{");
			iFoundKeyCnt = 0;

			for (j=0 ; szAllowKey[j]!=NULL ; j++)
			{
				pKey = szAllowKey[j];
				szGetValueByKey(szLine+3, pKey, szTmp, "");
				if (szTmp[0] == '\0')
					continue;
				sprintf(szTQDBKeyVal+strlen(szTQDBKeyVal), "%c'%s':%s", (iFoundKeyCnt==0?' ':','), pKey, szTmp);
				iFoundKeyCnt++;
			}
			sprintf(szTQDBKeyVal+strlen(szTQDBKeyVal), "}");
//strcpy(szSymbol,"KK");
			sprintf(szInsStr, "insert into %s.tick (symbol, datetime, type, keyval) values ('%s', %lld, %d, %s);",
                                pszDBName, szSymbol, llGetCurrentEpoch(), 0, szTQDBKeyVal);
			
			if (iDBGFlag==1)
	                        vMyLog(stdout, 1, "Statement: %s", szInsStr);
                        if (iCassExecuteInsertStatement(session, szInsStr) == 0)
                        {
                                exit(0);
                        }
			iInsertCnt++;
			iQuoteOrTick = 0;
		}
		if (iQuoteOrTick == -1)
			continue;
		if (iInsertCnt == 1||
		    (iInsertCnt>=100 && iInsertCnt<1000 && (iInsertCnt%100) == 0) ||
		    (iInsertCnt>=1000 && (iInsertCnt%1000) == 0) )
		{
			vMyLog(stdout, 1, "Inserted %d data", iInsertCnt);
			fflush(stdout);
		}
	}
	
	vMyLog(stdout, 1, "Graceful Exit.");
	fflush(stdout);
	if (1)//Close the session
	{
	    CassFuture* close_future = cass_session_close(session);
	    cass_future_wait(close_future);
	    cass_future_free(close_future);
	}
	cass_cluster_free(cluster);
	cass_session_free(session);
	exit(0);
	return 0;
}
