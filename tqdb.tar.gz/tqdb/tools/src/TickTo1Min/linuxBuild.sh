#!/bin/bash
g++ TickTo1Min.cpp -o ../../tick21min
