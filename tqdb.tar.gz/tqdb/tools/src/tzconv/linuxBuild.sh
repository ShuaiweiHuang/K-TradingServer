#!/bin/bash
rm tzconv 
gcc tzconv.c -o tzconv
